import SwiftUI

struct RedeemView: View {
    @Environment(\.colorScheme) var colorsScheme
    var body: some View {
        
        ZStack{
            colorsScheme == .dark ? Color.black.opacity(1) : Color.white
            ScrollView{
                VStack{
                    Text("Redeem your Trees🌳").fontWeight(.bold).font(.largeTitle)
                    GroupBox{
                        
                        VStack{
                            HStack{
                                Text("ESDA T-shirt").font(.title).bold().foregroundColor(.green)
                                Spacer()
                                Text("🌳500").font(.title).fontWeight(.bold)
                            }.padding(.bottom)
                            HStack{
                                Text("Exclusive T-Shirt:").fontWeight(.bold)
                                Spacer()
                            }
                            HStack{
                                Text("This is a T-shirt from ESDA NGO!")
                                Spacer()
                            }.padding(.bottom)
                            HStack{
                                Text("Shipping:").fontWeight(.bold)
                                Spacer()
                            }
                            HStack{
                                Text("+1$")
                                Spacer()
                            }.padding(.bottom)
                            
                            Button(action: {}, label: {
                                Text("BUY")
                            }).buttonStyle(.bordered)
                            
                        }
                    }.cornerRadius(30).padding()
                    
                    GroupBox{
                        
                        VStack{
                            HStack{
                                Text("Organic Kit").font(.title).bold().foregroundColor(.green)
                                Spacer()
                                Text("🌳1000").font(.title).fontWeight(.bold)
                            }.padding(.bottom)
                            HStack{
                                Text("Exclusive Kit:").fontWeight(.bold)
                                Spacer()
                            }
                            HStack{
                                Text("This is a Kit from ESDA NGO!")
                                Spacer()
                            }.padding(.bottom)
                            HStack{
                                Text("Shipping:").fontWeight(.bold)
                                Spacer()
                            }
                            HStack{
                                Text("+1$")
                                Spacer()
                            }.padding(.bottom)
                            
                            Button(action: {}, label: {
                                Text("BUY")
                            }).buttonStyle(.bordered)
                            
                        }
                    }.cornerRadius(30).padding()
                    
                    GroupBox{
                        
                        VStack{
                            HStack{
                                Text("Lifetime\nMembership").font(.title).bold().foregroundColor(.green)
                                Spacer()
                                Text("🌳2000").font(.title).fontWeight(.bold)
                            }.padding(.bottom)
                            HStack{
                                Text("Get a membership:").fontWeight(.bold)
                                Spacer()
                            }
                            HStack{
                                Text("Get lifetime membership from ESDA")
                                Spacer()
                            }.padding(.bottom)
                            
                            
                            Button(action: {}, label: {
                                Text("BUY")
                            }).buttonStyle(.bordered)
                            
                        }
                    }.cornerRadius(30).padding()
                }
            }  
        }
       
    }
}

struct RedeemView_Previews: PreviewProvider {
    static var previews: some View {
        RedeemView()
    }
}
