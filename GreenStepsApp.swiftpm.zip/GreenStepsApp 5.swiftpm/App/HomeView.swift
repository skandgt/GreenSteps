

import SwiftUI

struct HomeView: View {
    @State var currentSteps: Double = 2460
    let stepsGoal: Double = 5000
    var currentTrees = 1
    let treesGoal = 5
    var upPercent = 4.2
    var coQuantity = 102
    var calories = 131
    @State var progress: Double = 0
    
    var body: some View {
        ScrollView(showsIndicators: false){
            VStack {
                HStack{
                    Text("GreenSteps")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding().foregroundColor(.green)
                    Spacer()
                    VStack{
                        Image(information.memoji).resizable().frame(maxWidth: 40,maxHeight: 40).cornerRadius(50)
                        Text("Skand")
                    }
                }
                    VStack{
                        ZStack {
                            CircularProgressView(progress: progress,stepGoal: stepsGoal,currentSteps: currentSteps)
                            VStack{
                                Text("\(currentSteps,specifier: "%.0f")")
                                    .font(.custom("", size: 55).weight(.bold))
                                Text("steps")
                            }
                        }.frame(width: 230, height: 230).padding()
                        
                        Spacer()
                        Text("Goal: \(stepsGoal,specifier: "%.0f") steps").fontWeight(.bold).padding()
                    }
                
                GroupBox(label: HStack{Text("")})
                {
                    VStack{
                        Text("Trees Planted Today").fontWeight(.bold)
                        VStack{
                            Text(String(currentTrees)).font(.custom("", size: 70)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                            Text("of \(treesGoal) trees")
                        }
                        
                    }
                    
                    
                }.cornerRadius(30)
                
                HStack{
                    GroupBox(label: HStack{Text("")})
                    {
                        VStack{
                            Text("Calories Burnt").fontWeight(.bold)
                            HStack{
                                Text("\(calories)").font(.custom("", size: 50)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                                Text("kcal").font(.custom("", size: 20)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                            }
                            
                        }
                        
                        
                    }.cornerRadius(30)
                    
                    GroupBox(label: HStack{Text("")})
                    {
                        VStack{
                            Text("CO2 Reduced").fontWeight(.bold)
                            HStack{
                                Text("\(coQuantity)").font(.custom("", size: 50)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                                Text("g").font(.custom("", size: 20)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                            }
                            
                        }
                        
                        
                    }.cornerRadius(30)
                }
            }
        }}
    
    func resetProgress() {
        progress = 0
    }
    
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

struct CircularProgressView: View {
    let progress: Double
    let stepGoal: Double
    var currentSteps: Double
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(
                    Color.green.opacity(0.5),
                    lineWidth: 30
                )
            Circle()
                .trim(from: 0, to: currentSteps/stepGoal)
                .stroke(
                    .green,
                    style: StrokeStyle(
                        lineWidth: 30,
                        lineCap: .round
                    )
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeOut, value: progress)
            
        }
    }
}
