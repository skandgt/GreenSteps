
import SwiftUI
import Charts

struct ForestView: View {
    var totalTrees = 2560
    var coTotal = 191
    var distance = 102
    
    struct TreeStreak: Identifiable {
        var day: String
        var count: Double
        var id = UUID()
    }
    
    var data: [TreeStreak] = [
        .init(day: "Mon", count: 5),
        .init(day: "Tue", count: 4),
        .init(day: "Wed", count: 6),
        .init(day: "Thu", count: 7),
        .init(day: "Fri", count: 2),
        .init(day: "Sat", count: 3),
        .init(day: "Sun", count: 4)
    ]
    var body: some View {
        VStack {
            ScrollView {
            Text("My Forest")
                .font(.body)
                .fontWeight(.bold)
            Text("Total trees planted")
                .font(.title).foregroundColor(.green).fontWeight(.bold)
                .padding()
            Text(String(totalTrees))
                .font(.custom("", size: 90)).foregroundColor(.green)
                .fontWeight(.bold)
                
                    NavigationLink("Redeem", destination: RedeemView())
                    .buttonStyle(.bordered).padding(.bottom)
             
                HStack{
                    GroupBox(label: HStack{Text("")})
                    {
                        VStack{
                            Text("CO2 Reduced").fontWeight(.bold)
                            HStack{
                                Text("\(coTotal)").font(.custom("", size: 50)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                                Text("kg").font(.custom("", size: 20)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                            }
                            //                        Text("⬆20% from tomorrow").foregroundColor(.green)
                            
                        }
                        
                        
                    }.cornerRadius(30)
                    
                    GroupBox(label: HStack{Text("")})
                    {
                        VStack{
                            Text("Distance covered").fontWeight(.bold)
                            HStack{
                                Text("\(distance)").font(.custom("", size: 50)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                                Text("km").font(.custom("", size: 20)).fontWeight(.bold).padding(.top).foregroundColor(.green)
                            }
                            //                        Text("⬆20% from tomorrow").foregroundColor(.green)
                            
                        }
                        
                        
                    }.cornerRadius(30)
                }
                
                Text("Streaks").padding(.top,110)
                
                Chart {
                    ForEach(data) { shape in
                        BarMark(
                            x: .value("Days", shape.day),
                            y: .value("Total Count", shape.count)
                        )
                    }
                }
                
            }
            
            
        }
        
    }
}

struct ForestView_Previews: PreviewProvider {
    static var previews: some View {
        ForestView()
    }
}

struct BrownGroupBox: GroupBoxStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.content
            .frame(maxWidth: .infinity)
            .padding()
            .background(RoundedRectangle(cornerRadius: 30).fill(Color.brown))
            .overlay(configuration.label.padding(.leading, 4), alignment: .topLeading)
    }
}

