
import SwiftUI

struct ContentView: View {
    @Environment(\.colorScheme) var colorsScheme
    
    var body: some View {
        NavigationView{
            ZStack{
                colorsScheme == .dark ? Color.black.opacity(1) : Color.white
                TabView {
                    ZStack{
                        colorsScheme == .dark ? Color.black.opacity(1) : Color.white
                        HomeView().padding(.top).padding(.leading).padding(.trailing)
                    }.tabItem {
                        Label("Home", systemImage: "house")
                    }
                    
                    
                    ZStack{
                        colorsScheme == .dark ? Color.black.opacity(1) : Color.white
                        ForestView().padding(.top).padding(.leading).padding(.trailing)
                    }.tabItem {
                        Label("Forest", systemImage: "tree")
                    }
                    
                    
                    ZStack{
                        colorsScheme == .dark ? Color.black.opacity(1) : Color.white
                        ProfileView().padding(.top).padding(.leading).padding(.trailing)
                    }
                    .tabItem {
                        Label("You", systemImage: "person")
                    }
                }
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
