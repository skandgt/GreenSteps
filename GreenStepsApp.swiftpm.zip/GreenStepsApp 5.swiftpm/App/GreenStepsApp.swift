
import SwiftUI

@main
struct GreenStepsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
