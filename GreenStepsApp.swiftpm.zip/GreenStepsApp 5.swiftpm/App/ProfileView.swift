
import SwiftUI

struct ProfileView: View {
    var coReduced = 1270
    
    
    var body: some View {
        ScrollView(showsIndicators: false){
            VStack {
                HStack{
                    Text("Friends").font(.largeTitle)
                        .fontWeight(.bold)
                    Spacer()
                }
                
                GroupBox{
                    HStack{
                        Image(information.memoji).resizable().frame(maxWidth: 30,maxHeight: 30).cornerRadius(100)
                        Text("Skand").font(.body).fontWeight(.bold)
                        Spacer()
                        Text("🌳2,560").font(.title).fontWeight(.bold).foregroundColor(.green)
                    }
                    
                    HStack{
                        Image(information.memoji3).resizable().frame(maxWidth: 30,maxHeight: 30).cornerRadius(100)
                        Text("Alex").font(.body).fontWeight(.bold)
                        Spacer()
                        Text("🌳2,160").font(.title).fontWeight(.bold).foregroundColor(.green)
                    }
                    
                    HStack{
                        Image(information.memoji4).resizable().frame(maxWidth: 30,maxHeight: 30).cornerRadius(100)
                        Text("Siri").font(.body).fontWeight(.bold)
                        Spacer()
                        Text("🌳1,720").font(.title).fontWeight(.bold).foregroundColor(.green)
                    }
                    
                    HStack{
                        Image(information.memoji5).resizable().frame(maxWidth: 30,maxHeight: 30).cornerRadius(100)
                        Text("Shubh").font(.body).fontWeight(.bold)
                        Spacer()
                        Text("🌳970").font(.title).fontWeight(.bold).foregroundColor(.green)
                    }
                    
                    HStack{
                        Image(information.memoji2).resizable().frame(maxWidth: 30,maxHeight: 30).cornerRadius(100)
                        Text("Naman").font(.body).fontWeight(.bold)
                        Spacer()
                        Text("🌳160").font(.title).fontWeight(.bold).foregroundColor(.green)
                    }
                    
                }.cornerRadius(30)
                
                HStack{
                    Text("Events").font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.top,40)
                    Spacer()
                }
                Text("Upcoming").foregroundColor(.gray)
                
                GroupBox{
                    
                    VStack{
                        HStack{
                            Text("Marathon").font(.title).bold().foregroundColor(.green)
                            Spacer()
                            Text("22/11/2024").font(.body).fontWeight(.bold).foregroundColor(.gray)
                        }.padding(.bottom)
                        HStack{
                            Text("About this Campaign:").fontWeight(.bold)
                            Spacer()
                        }
                        HStack{
                            Text("This is a marathon drive which will help in reducing the carbon footprint.")
                            Spacer()
                        }.padding(.bottom)
                        HStack{
                            Text("Venue:").fontWeight(.bold)
                            Spacer()
                        }
                        HStack{
                            Text("Saket, New Delhi")
                            Spacer()
                        }.padding(.bottom)
                        
                        Button(action: {}, label: {
                            Text("Join")
                        }).buttonStyle(.bordered)
                        
                    }
                }.cornerRadius(30)
                
                GroupBox{
                    
                    VStack{
                        HStack{
                            Text("Plantation Drive").font(.title).bold().foregroundColor(.green)
                            Spacer()
                            Text("19/04/2024").font(.body).fontWeight(.bold).foregroundColor(.gray)
                        }.padding(.bottom)
                        HStack{
                            Text("About this Campaign:").fontWeight(.bold)
                            Spacer()
                        }
                        HStack{
                            Text("This is a plantation drive which will help in reforestation on the planet Earth.")
                            Spacer()
                        }.padding(.bottom)
                        HStack{
                            Text("Venue:").fontWeight(.bold)
                            Spacer()
                        }
                        HStack{
                            Text("New Garden, Pune")
                            Spacer()
                        }.padding(.bottom)
                        
                        Button(action: {}, label: {
                            Text("Join")
                        }).buttonStyle(.bordered)
                        
                    }
                }.cornerRadius(30)
                
            }
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
