
import Foundation
import SwiftUI

struct Info {
    let memoji: String
    let memoji2: String
    let memoji3: String
    let memoji4: String
    let memoji5: String
}

let information = Info(
    memoji: "memomoji",
    memoji2: "memoji2",
    memoji3: "memo3",
    memoji4: "memo4",
    memoji5: "memo5"
)
